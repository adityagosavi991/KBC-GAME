#############################################################
ReadMe for assignment submitted by : VANSH BANSAL(ID:2019B4PS0621P)
Practical section number: P3
Asignment question attempted: 1
#############################################################
Team:
1. 2019B1PS0963P   ADITYA SANDEEP GOSAVI
2. 2019B4PS0621P   VANSH BANSAL
#############################################################
Description of how to run the code and observe the output:
1.WHEN YOU RUN THE CODE:
A.Information and rules about this KBC game will be displayed. 
B.It will ask user to press any key(except 'q' or 'Q')to start the game.
C.Press 'q' or 'Q' to end the game immediately.
2.WHen THE GAME STARTS:
A.Questions are displayed sequentially.
B.User must respond to the given question as instructed on the screen (keeping in mind,the rules of this game).
RESPOND-1:PRESS '0' to use any lifeline.(PRESS '100' FOR 50-50 lifeline or PRESS '200'FoR 'FLIP-QUESTION' lifeline.
RESPOND-2:PRESS '1','2','3','4' to answer the given question.
RESPOND-3:PRESS '-1' to QUIT the game (RULE:YOU CANNOT QUIT THE GAME,IF ANY OF THE LIFELINE IS ACTIVATED IN A GIVEN QUESTION).
3.WHEN THE GAME ENDS:
1.Total prize money won by the user is displayed.
############################################################
ASSUMPTIONS MADE IN THE ASSIGNMENT:
1.User doesn't type anything else,other then what is instructed on screen.
2.If user doesn't type what is instructed,the game won't run accordingly.
############################################################
Contributions of the team members:
ADITYA made an intial code,did editting during the course,added comments.
VANSH helped in code to identify the faults,rectify them to increase efficiency,also did the indentation and added comments.  
#############################################################
